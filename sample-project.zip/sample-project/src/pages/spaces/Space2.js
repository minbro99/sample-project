import React from 'react';
import { Link } from 'react-router-dom';
import nuriflexImg from './nurihomepic.png';

function Space2() {
  return (
    <div style={{ textAlign: 'center' }}>
      <div style={{ marginTop: '0px', display: 'flex', justifyContent: 'center' }}>
        <img src={nuriflexImg} alt='nuri homepic' style={{ width: '1300px', height: '150px' }} />
      </div>
      <h2>(Nuri) 공용 홈</h2>
      
      <p>작성자 : <Link to='https://confluence.nuriflex.co.kr/display/~NURIadmin'>누리관리자</Link>, 최근변경 : <Link to='/hkd'>홍길동</Link> - <Link to='https://confluence.nuriflex.co.kr/pages/diffpagesbyversion.action?pageId=60537063&selectedPageVersions=16&selectedPageVersions=17'>1월 02, 2024</Link></p>
      
      <fieldset style={{ textAlign: 'left', width: 'fit-content', margin: 'auto' }}>
        <legend>이 작업을 완료하고, 시작하세요</legend>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <input type="checkbox" id="coding" name="interest" value="coding" style={{ marginRight: '10px' }} />
          <label htmlFor="coding">홈 페이지를 수정하세요 - 이 화면 오른쪽 위의 수정을 클릭해 공간 홈 페이지를 입맛대로 설정하세요</label>
        </div>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <input type="checkbox" id="music1" name="interest" value="music1" style={{ marginRight: '10px' }} />
          <label htmlFor="music1">첫 페이지를 만드세요 - 상단의 만들기 버튼을 클릭해 시작하세요</label>
        </div>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <input type="checkbox" id="music2" name="interest" value="music2" style={{ marginRight: '10px' }} />
          <label htmlFor="music2">나만의 공간을 만드세요 - 왼쪽 패널에서 사이드바 설정을 클릭해 공간 상세 내용과 로고를 수정하세요</label>
        </div>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <input type="checkbox" id="music3" name="interest" value="music3" style={{ marginRight: '10px' }} />
          <label htmlFor="music3">권한을 설정하세요 - 왼쪽 사이드바의 공간 도구를 클릭해 권한을 수정하고 다른 사람에게 접근 권한을 부여하세요</label>
        </div>
      </fieldset>
      
      <h4>최근 공간 활동</h4>
      <p><Link to='/kcs'>김철수</Link><br></br>
      <Link to='/kcs-202407'>김철수-2024년 07월</Link> 수정됨 5분 전</p>
      <p><Link to='/pms'>박민수</Link><br></br>
      <Link to='/pms-202407'>박민수-2024년 07월</Link> 수정됨 20분 전</p>
      <p><Link to='/lmc'>이민철</Link><br></br>
      <Link to='/lmc-202407'>이민철-2024년 07월</Link> 수정됨 32분 전</p>
      <p><Link to='https://confluence.nuriflex.co.kr/display/~rnd.fe9'>김민형</Link><br></br>
      <Link to='https://confluence.nuriflex.co.kr/pages/viewpage.action?pageId=230298508'>김민형-2024년 07월</Link> 수정됨 3시간 전</p>
    </div>
  )
}

export default Space2;
