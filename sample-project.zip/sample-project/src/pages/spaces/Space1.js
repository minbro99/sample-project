import React from 'react';
import { Link } from 'react-router-dom';
import nuriflexImg from './nurihomepic.png';

function Space1() {
  return (
    <div style={{ textAlign: 'center' }}>
      <div style={{ marginTop: '0px', display: 'flex', justifyContent: 'center' }}>
        <img src={nuriflexImg} alt='nuri homepic' style={{ width: '1300px', height: '150px' }} />
      </div>
      <h2>(Nuri) 제2연구소 Home</h2>
      <p>작성자 :  <Link to='https://confluence.nuriflex.co.kr/display/~NURIadmin'>누리관리자</Link>, 최근변경 : <Link to='/hkd'>홍길동</Link> - <Link to='https://confluence.nuriflex.co.kr/pages/diffpagesbyversion.action?pageId=60537063&selectedPageVersions=16&selectedPageVersions=17'>1월 02, 2024</Link></p>
      <h4>최근 공간 활동</h4>
      <div style={{ display: 'flex', justifyContent: 'center', flexDirection: 'column', alignItems: 'center' }}>
        <p><Link to='/kcs'>김철수</Link><br />
          <Link to='/kcs-202407'>김철수-2024년 07월</Link> 수정됨 5분 전</p>
        <p><Link to='/pms'>박민수</Link><br />
          <Link to='/pms-202407'>박민수-2024년 07월</Link> 수정됨 20분 전</p>
        <p><Link to='/lmc'>이민철</Link><br />
          <Link to='/lmc-202407'>이민철-2024년 07월</Link> 수정됨 32분 전</p>
        <p><Link to='https://confluence.nuriflex.co.kr/display/~rnd.fe9'>김민형</Link><br />
          <Link to='https://confluence.nuriflex.co.kr/pages/viewpage.action?pageId=230298508'>김민형-2024년 07월</Link> 수정됨 3시간 전</p>
      </div>
    </div>
  )
};

export default Space1;
