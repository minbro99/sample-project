/* eslint-disable */
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './Login.css';


function Login() {
  const [userName, setUserName] = useState('');
  const [userPassword, setUserPassword] = useState('');
  const navigate = useNavigate(); // useNavigate 훅 사용

  const handleLoginClick = (event) => {
    event.preventDefault();

    // 여기서 실제 아이디와 비밀번호를 확인합니다.
    const validUserName = 'abc123@nuriflex.com';
    const validPassword = '10101010';

    if (userName === validUserName && userPassword === validPassword) {
      
      navigate('/loginSuccess');
    } else {
      navigate('/LoginFail');
    }
  };

  return (
    
    <div className="container">
      <h2>Login</h2>
      <form method="post" action="login-success" id="login-form">
        <input 
          type="text" 
          name="userName" 
          placeholder="Email" 
          value={userName}
          onChange={(e) => setUserName(e.target.value)} 
        /><br />
        <input 
          type="password" 
          name="userPassword" 
          placeholder="Password" 
          value={userPassword}
          onChange={(e) => setUserPassword(e.target.value)} 
        /><br />
        <label htmlFor="remember-check">
          <input type="checkbox" id="remember-check" />아이디 저장하기 <br />
        </label>
      </form>
      
      <button onClick={handleLoginClick}>
        로그인
      </button>
    </div>
  );
}

export default Login;
