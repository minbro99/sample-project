// Modal.js
import React from 'react';
import './Modal.css';

const Modal = ({ show, handleClose, title, children }) => {
  if (!show) {
    return null;
  }

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <div className="modal-header">
          <h4>{title}</h4>
          <button onClick={handleClose} className="modal-close-button">X</button>
        </div>
        <div className="modal-body">
          {children}
        </div>
        <div className="modal-footer">
          <button onClick={handleClose} className="modal-button">확인</button>
        </div>
      </div>
    </div>
  );
};

export default Modal;
