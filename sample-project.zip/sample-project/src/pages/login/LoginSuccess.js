import React, { useState } from 'react';
import Modal from './Modal'; // 모달 컴포넌트를 임포트합니다.

function LoginSuccess() {
  const [showModal, setShowModal] = useState(true);

  const handleClose = () => setShowModal(false);

  return (
    <div>
      

      <Modal show={showModal} handleClose={handleClose} title="로그인 성공">
        로그인에 성공하셨습니다!
      </Modal>
    </div>
  );
}

export default LoginSuccess;
