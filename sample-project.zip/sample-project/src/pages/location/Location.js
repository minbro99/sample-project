import React from 'react';
import nuriflexImage from './nurihomepic.png';
import Button from 'react-bootstrap/Button';
import { Link } from 'react-router-dom';

function Location() {
  return (
    <div>
      <div style={{ marginTop: '0px', display: 'flex', justifyContent: 'center' }}>
        <img src={nuriflexImage} alt='nuri homepic' style={{ width: '1300px', height: '150px' }} />
      </div>
      
      <h2 style={{ textAlign: 'center' }}>Location</h2>
      
      <div style={{ display: 'flex', justifyContent: 'space-between', margin: '0 200px' }}>
        <Link to='/headquarter' style={{ flex: 1, marginRight: '10px' }}>
          <Button variant="primary" size="lg">
            Headquarter
          </Button>
        </Link>
        
        <Link to='/overseas-corporation' style={{ flex: 1, marginLeft: '10px' }}>
          <Button variant="secondary" size="lg">
            Overseas Corporation
          </Button>
        </Link>
      </div>
    </div>
  );
}

export default Location;
