import React, { useState } from 'react';
import nuriflexImage from './nurihomepic.png';
import './overseas-corporation.css'; // CSS 파일 임포트
import Nuriflexjapan from './nuriflexjapan.png';
import Nuriflexvietnam from './nuriflexvietnam.png';

const OverseasCorporation = () => {
    const [showButton1Content, setShowButton1Content] = useState(false);
    const [showButton2Content, setShowButton2Content] = useState(false);

    const handleButtonClick = (buttonNumber) => {
        if (buttonNumber === 1) {
            setShowButton1Content(true);
            setShowButton2Content(false);
        } else if (buttonNumber === 2) {
            setShowButton1Content(false);
            setShowButton2Content(true);
        }
    };

    return (
        <div className="overseas-corporation-container">
            <div style={{ marginTop: '0px', display: 'flex', justifyContent: 'center' }}>
                <img src={nuriflexImage} alt='nuri homepic' style={{ width: '1300px', height: '150px' }} />
            </div>

            <div className="button-container">
                <button className="corporation-button" onClick={() => handleButtonClick(1)}>Nuriflex Japan</button>
                <button className="corporation-button" onClick={() => handleButtonClick(2)}>Nuriflex Vietnam</button>
            </div>

            {showButton1Content && (
                <div className="corporation-content">
                    <h2>Nuriflex Japan</h2>
                    <p>
                        <img src={Nuriflexjapan} alt='nuriflex japan' style={{ width: '800px', height: 'auto', marginTop: '10px' }} />
                    </p>
                </div>
            )}

            {showButton2Content && (
                <div className="corporation-content">
                    <h2>Nuriflex Vietnam</h2>
                    <p>
                        <img src={Nuriflexvietnam} alt='nuriflex vietnam' style={{ width: '800px', height: 'auto', marginTop: '10px' }} />
                    </p>
                </div>
            )}
        </div>
    );
};

export default OverseasCorporation;
