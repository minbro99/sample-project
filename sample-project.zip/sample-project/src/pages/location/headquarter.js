import React from 'react';
import nuriflexImage from './nurihomepic.png';
import Nuriflexlocation1 from './nuriflexlocation.png';
import Nuriflexnaju1 from './nuriflexnaju1.png';
import Nuriflexnaju2 from './nuriflexnaju2.png';
import './headquarter.css';

function Headquarter() {
  return (
    
    <div style={{ textAlign: 'center' }}>
      <div style={{ marginTop: '0px', display: 'flex', justifyContent: 'center' }}>
        <img src={nuriflexImage} alt='nuri homepic' style={{ width: '1300px', height: '150px' }} />
      </div>
      <p>
        <h1 style={{ margin: '10px 0' }}>본사 위치</h1>
        <a href='https://map.naver.com/p/entry/place/1050118489?c=15.42,0,0,0,dh'> 
          <img src={Nuriflexlocation1} alt='nuriflex location1' style={{ width: '70%', height: 'auto', marginTop: '10px' }} />
        </a>
        <div className='info'>
          <div className='contact_tel'>
            <p style={{ fontSize: '15px', margin: 0, padding: 0 }}>본사 대표번호</p>
            <p style={{ fontSize: '1.438em', margin: 0, padding: 0 }}>02-781-0700</p>
          </div>
          <ul className="comm ul">
            <li className='comm li'>도로명 주소: 서울시 서초구 사평대로 16 누리빌딩</li>
            <li className='comm li'>지번주소: 서울시 서초구 방배동 750-14 누리빌딩</li>
          </ul>
        </div>

        <div className="transport-info">
          <div className="transport-section">
            <h4 style={{color: '#f25255'}}>🚇지하철 이용시</h4>
            <p>
              9호선 구반포역 1번출구 : 이수교차로(반포IC) 방면으로 도보 5분 <br></br>
              4, 9호선 동작역 1번출구 : 허밍웨이길로 이수교차로(반포IC) 방면으로 도보 10분<br></br>
              4호선 이수역 1번출구 : 이수교차로 방면 모든 버스 이용 이수정류장 하차 도보 5분<br></br>
              2호선 서초역 2번출구 : 마을버스(녹색) 21번 승차 동부 센트레빌 정류장 하차
            </p>
          </div>
          <div className="transport-section">
            <h4 style={{color: '#e65488'}}>🚍버스 이용시</h4>
            <p>
              간선버스(파란색) : 142, 148, 406번 삼호 아파트 하차 후 100M 직진 후 한샘 옆 이수교차로 방향 100M 직진<br></br>
              마을버스 : 14번 방배 신삼호아파트 하차 100M 직진 후 한샘 옆 이수교차로 방향 100M 직진<br></br>
              10, 21번 동부 센트레빌 정류장 하차 횡단보도 건너 한샘 옆 이수교차로 방향 100M 직진
            </p>
          </div>
        </div>

        <h1 style={{ margin: '10px 0' }}>나주제조센터</h1>
        <a href='https://www.google.com/maps/dir//%EB%82%98%EC%A3%BC%ED%98%81%EC%8B%A0%EC%82%B0%EB%8B%A8(%EC%A3%BC)+%EB%82%98%EC%A3%BC%EC%8B%9C/data=!4m8!4m7!1m0!1m5!1m1!1s0x35723239f10270c9:0x815c1ece6425f305!2m2!1d126.6790654!2d34.9686237?entry=ttu'> 
          <img src={Nuriflexnaju1} alt='nuriflex location2' style={{ width: '70%', height: 'auto', marginTop: '10px' }} />
        </a>
        <div className='info'>
          <ul className="comm ul">
            <li className='comm li'>도로명 주소: 전라남도 나주시 혁신단지5길 33</li>
          </ul>
        </div>

        <h1 style={{ margin: '10px 0' }}>나주사무소</h1>
        <a href='https://www.google.com/maps/dir//%ED%86%A0%EB%8B%B4+%EB%A6%AC%EC%B9%98%ED%83%80%EC%9B%8C+%EC%A0%84%EB%9D%BC%EB%82%A8%EB%8F%84+%EB%82%98%EC%A3%BC%EC%8B%9C+%EA%B8%88%EC%B2%9C%EB%A9%B4+%EC%9A%B0%EC%A0%95%EB%A1%9C+56/@35.023758,126.7858026,18z/data=!4m5!4m4!1m0!1m2!1m1!1s0x3572253f20dea981:0x3758625f0bdd25a8'> 
          <img src={Nuriflexnaju2} alt='nuriflex location2' style={{ width: '70%', height: 'auto', marginTop: '10px' }} />
        </a>
        <div className='info'>
          <ul className="comm ul">
            <li className='comm li'>나주사무소 주소: 전라남도 나주시 우정로 56 토담리치타워 A동 501호</li>
          </ul>
        </div>
      </p>
    </div>
  );
}

export default Headquarter;
