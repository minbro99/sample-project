import React from 'react';

import nuriflexImage from './nuriflexhompagelogo.png'; // 상대 경로로 이미지 import
import nuriflexImg from './nurihomepic.png';

function Home() {
    return (
        <div>
            <div style={{ marginTop: '0px', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                <img src={nuriflexImg} alt='nuri homepic' style={{ width: '1300px', height: '150px' }} />
                <a href='http://www.nuritelecom.com/kr/main/main.html'> 
                    <img src={nuriflexImage} alt='nuriflex homepage' style={{ width: '300px', height: 'auto', marginTop: '10px' }} />
                </a>
                <h4 style={{ margin: '10px 0' }}>회사 홈페이지 URL</h4>
            </div>
            <p style={{ textAlign: 'center' }}>
            </p>
        </div>
    )
};

export default Home;
