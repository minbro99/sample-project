import React from 'react';
import nuriflexImage from './nurihomepic.png';

const Contact = () => {
    const tables = [
        {
            title: '사업문의',
            data: [
                { category: 'AMI (국내)', phone: ['02-781-0774'], email: 'ami_sales@nuriflex.co.kr' },
                { category: 'AMI (해외)', phone: ['02-781-0743'], email: 'ami_global@nuriflex.co.kr' },
                { category: 'APT AMI (가정용 스마트전력 플랫폼)', phone: ['02-781-0606', '02-781-0794', '02-781-0668'], email: 'aptami@nuriflex.co.kr' },
                { category: 'Other business', phone: ['02-781-0667', '02-781-0665', '02-781-0731'], email: 'business@nuriflex.co.kr' }
            ]
        },
        {
            title: '기업문의',
            data: [
                { category: '기술연구소', phone: ['02-781-0763'], email: 'technical@nuriflex.co.kr' }
            ]
        },
        {
            title: '일반문의',
            data: [
                { category: '채용', phone: ['02-781-0725', '02-781-0650'], email: 'general@nuriflex.co.kr' },
                { category: '홍보/IR', phone: ['02-781-0792'], email: 'general@nuriflex.co.kr' }
            ]
        }
    ];

    return (
        <React.Fragment>
            <div style={{ marginTop: '0px', display: 'flex', justifyContent: 'center' }}>
                <img src={nuriflexImage} alt='nuri homepic' style={{ width: '1300px', height: '150px' }} />
            </div>
            <div >
                {tables.map((table, tableIndex) => (
                    <div key={tableIndex}>
                        <h1>{table.title}</h1>
                        <table border="1" style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '20px' }}>
                            <thead>
                                <tr style={{ backgroundColor: '#f2f2f2', textAlign: 'center' }}>
                                    <th style={{ padding: '10px', border: '1px solid #ddd' }}>Category</th>
                                    <th style={{ padding: '10px', border: '1px solid #ddd' }}>Phone</th>
                                    <th style={{ padding: '10px', border: '1px solid #ddd' }}>Email</th>
                                </tr>
                            </thead>
                            <tbody>
                                {table.data.map((row, rowIndex) => (
                                    <tr key={rowIndex}>
                                        <td style={{ padding: '10px', border: '1px solid #ddd', textAlign: 'center' }}>{row.category}</td>
                                        <td style={{ padding: '10px', border: '1px solid #ddd', textAlign: 'center' }}>
                                            {row.phone.map((phoneNumber, index) => (
                                                <div key={index}>
                                                    {index > 0 && <br />}
                                                    {phoneNumber}
                                                </div>
                                            ))}
                                        </td>
                                        <td style={{ padding: '10px', border: '1px solid #ddd', textAlign: 'center' }}>{row.email}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                ))}
            </div>
        </React.Fragment>
    );
}

export default Contact;
