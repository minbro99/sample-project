import React from 'react';
import { Link } from 'react-router-dom';
import nuriflexImg from './nurihomepic.png';

function Confluence() {
  return (
    <div style={{ textAlign: 'center' }}>
      <div style={{ marginTop: '0px', display: 'flex', justifyContent: 'center' }}>
        <img src={nuriflexImg} alt='nuri homepic' style={{ width: '1300px', height: '150px' }} />
      </div>
      <h2>
        <Link to="https://confluence.nuriflex.co.kr/#recently-worked">confluence</Link>
      </h2>
      <h4>최근에 작업한</h4>
      <p>
        오늘
      </p>
      <div style={{ textAlign: 'center' }}>
        <Link to="https://confluence.nuriflex.co.kr/pages/viewpage.action?pageId=230298508">김민형-2024년 07월</Link><br />
        <Link to="./hkd-202407">홍길동-2024년 07월</Link>
      </div>
      <p>
        마지막 주
      </p>
      <div style={{ textAlign: 'center' }}>
        <Link to="./">김민형-2024년 06월</Link><br />
        <Link to="./hkd-202406">홍길동-2024년 06월</Link>
      </div>
      <p>
        한달 이상 이전
      </p>
      <div style={{ textAlign: 'center' }}>
        <Link to="https://confluence.nuriflex.co.kr/pages/viewpage.action?pageId=206962865">김민형-2024년 05월</Link><br />
        <Link to="./hkd-202405">홍길동-2024년 05월</Link>
      </div>
    </div>
  );
}

export default Confluence;
