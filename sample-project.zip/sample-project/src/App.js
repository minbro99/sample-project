import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import Confluence from './pages/navbar/Confluence'; 
import Home from './pages/navbar/Home';
import Contact from './pages/navbar/Contact';
import Location from './pages/location/Location';
import People from './pages/navbar/People';
import Space1 from './pages/spaces/Space1';
import Space2 from './pages/spaces/Space2';
import Space3 from './pages/spaces/Space3';
import Login from './pages/login/Login';
import LoginSuccess from './pages/login/LoginSuccess';
import LoginFail from './pages/login/LoginFali';
import Headquarter from './pages/location/headquarter';
import OverseasCorporation from './pages/location/overseas-corporation';


function App() {
    return (
      <>
        <Router>
          <Navbar />
          <Routes>
            <Route path='/' element={<Home />} />
            <Route path='/confluence' element={<Confluence />} />           
            <Route path='/people' element={<People />} />
            <Route path='/Contact' element={<Contact />} />
            <Route path='/location' element={<Location />} />
            <Route path='/space1' element={<Space1 />} />
            <Route path='/space2' element={<Space2 />} />
            <Route path='/space3' element={<Space3 />} />
            <Route path='/login' element={<Login />} />
            <Route path='/loginSuccess' element={<LoginSuccess />} />
            <Route path='/loginFail' element={<LoginFail />} />
            <Route path='/headquarter' element={<Headquarter />} />
            <Route path='/overseas-corporation' element={<OverseasCorporation />} />
          </Routes>
        </Router>
      </>
    );
}

export default App;
